package it.unicam.cs.asdl2425.mp1;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

//TODO inserire gli import della Java SE che si ritengono necessari

/**
 * Una classe che rappresenta una lista concatenata con il calcolo degli hash
 * MD5 per ciascun elemento. Ogni nodo della lista contiene il dato originale di
 * tipo generico T e il relativo hash calcolato utilizzando l'algoritmo MD5.
 *
 * <p>
 * La classe supporta le seguenti operazioni principali:
 * <ul>
 * <li>Aggiungere un elemento in testa alla lista</li>
 * <li>Aggiungere un elemento in coda alla lista</li>
 * <li>Rimuovere un elemento dalla lista in base al dato</li>
 * <li>Recuperare una lista ordinata di tutti gli hash contenuti nella
 * lista</li>
 * <li>Costruire una rappresentazione testuale della lista</li>
 * </ul>
 *
 * <p>
 * Questa implementazione include ottimizzazioni come il mantenimento di un
 * riferimento all'ultimo nodo della lista (tail), che rende l'inserimento in
 * coda un'operazione O(1).
 *
 * <p>
 * La classe utilizza la classe HashUtil per calcolare l'hash MD5 dei dati.
 *
 * @param <T>
 *                il tipo generico dei dati contenuti nei nodi della lista.
 * 
 * @author Luca Tesei, Marco Caputo (template), Matteo Vittori matteo01.vittori@studenti.unicam.it (implementazione)

 * 
 */
public class HashLinkedList<T> implements Iterable<T> {
    private Node head; // Primo nodo della lista

    private Node tail; // Ultimo nodo della lista

    private int size; // Numero di nodi della lista

    private int numeroModifiche; // Numero di modifiche effettuate sulla lista
                                 // per l'implementazione dell'iteratore
                                 // fail-fast
    /**
     * Parametro utilizzato per evitare di dover riscrivere ogni volta il messaggio
     * di errore nel caso di input nullo
     */
    private static final String NULL_INPUT_ERROR = 
    		"==ERRORE: il dato inserito non può essere null==";
    

    public HashLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
        this.numeroModifiche = 0;
    }

    /**
     * Restituisce il numero attuale di nodi nella lista.
     *
     * @return il numero di nodi nella lista.
     */
    public int getSize() {
        return size;
    }

    /**
     * Rappresenta un nodo nella lista concatenata.
     */
    private class Node {
        String hash; // Hash del dato

        T data; // Dato originale

        Node next;

        Node(T data) {
            this.data = data;
            this.hash = HashUtil.dataToHash(data);
            this.next = null;
        }
    }

    /**
     * Aggiunge un nuovo elemento in testa alla lista.
     *
     * @param data
     *                 il dato da aggiungere.
     */
    public void addAtHead(T data) {
    	// Controlla se il dato è null e lancia un'eccezione se lo è.
    	if(data == null) 
    		throw new IllegalArgumentException(NULL_INPUT_ERROR);
    	
    	// Crea un nuovo nodo utilizzando il costruttore della classe Node.
    	Node newNode = new Node(data);
    	// Collega il nuovo nodo al nodo attualmente in testa.
        // Se la lista è vuota, 'head' è inizialmente null, quindi va bene assegnare 'next' così.
    	newNode.next = head;
    	head = newNode;
    	// Se la lista era vuota, anche la coda deve puntare al nuovo nodo.
        // Questo garantisce che tail sia sempre aggiornato correttamente.
    	if(size == 0) 
    		tail = newNode;
    	// incrementa size e il numero di modifiche
    	size++;
    	numeroModifiche++;
    }

    /**
     * Aggiunge un nuovo elemento in coda alla lista.
     *
     * @param data
     *                 il dato da aggiungere.
     */
    public void addAtTail(T data) {
    	// Controlla se il dato è null e lancia un'eccezione se lo è.
    	if(data == null) 
    		throw new IllegalArgumentException(NULL_INPUT_ERROR);
    	
    	// Se la lista è vuota (size == 0), utilizza il metodo addAtHead.
        // Questo assicura che sia 'head' che 'tail' vengano aggiornati correttamente
        // quando si aggiunge il primo elemento.
    	if(size == 0) {
    		addAtHead(data);
    		return;			// Esce dal metodo, poiché il lavoro è già stato fatto.
    	}
    	// Crea un nuovo nodo utilizzando il costruttore della classe Node.
    	Node newNode = new Node(data);   
    	// Collega il nodo attuale in coda al nuovo nodo.
    	tail.next = newNode;
    	// Aggiorna la coda della lista, puntandola al nuovo nodo.
    	tail = newNode;
    	
    	// incrementa size e il numero di modifiche
    	size++;
    	numeroModifiche++;
    }

    /**
     * Restituisce un'ArrayList contenente tutti gli hash nella lista in ordine.
     *
     * @return una lista con tutti gli hash della lista.
     */
    public ArrayList<String> getAllHashes() {

    	ArrayList<String> result = new ArrayList<>();
    	Node current = head;
    	
    	// Il ciclo while scorre la lista concatenata finché non si raggiunge la fine
    	while(current != null) {
    		result.add(current.hash);	// Aggiunge l'hash del nodo corrente all'ArrayList.
    		current = current.next;		// Passa al nodo successivo della lista.
    	}
    	
    	//restituisce l'arrayList creato
        return result;
    }

    /**
     * Costruisce una stringa contenente tutti i nodi della lista, includendo
     * dati e hash. La stringa dovrebbe essere formattata come nel seguente
     * esempio:
     * 
     * <pre>
     *     Dato: StringaDato1, Hash: 5d41402abc4b2a76b9719d911017c592
     *     Dato: SteringaDato2, Hash: 7b8b965ad4bca0e41ab51de7b31363a1
     *     ...
     *     Dato: StringaDatoN, Hash: 2c6ee3d301aaf375b8f026980e7c7e1c
     * </pre>
     *
     * @return una rappresentazione testuale di tutti i nodi nella lista.
     */
    public String buildNodesString() {
        
    	// Usa StringBuilder per una concatenazione più efficiente delle stringhe
    	StringBuilder result = new StringBuilder();
    	
    	// Il ciclo for scorre la lista concatenata finché non si raggiunge la fine
    	for (Node current = head; current != null; current = current.next) 
    		result.append("Dato: ").append(current.data.toString())	// crea la stringa nel formato richiesto
    			  .append(", Hash: ").append(current.hash).append("\n");
    	
        return result.toString();	// Restituisce la stringa concatenata
    }

    /**
     * Rimuove il primo elemento nella lista che contiene il dato specificato.
     *
     * @param data
     *                 il dato da rimuovere.
     * @return true se l'elemento è stato trovato e rimosso, false altrimenti.
     */
    public boolean remove(T data) {
    	// Controlla se il dato è null e lancia un'eccezione se lo è.
    	if (data == null) 
            throw new IllegalArgumentException(NULL_INPUT_ERROR);

        // Se la lista è vuota, non possiamo rimuovere nulla
        if (head == null) {
            return false;
        }

        // controllo il caso in cui il dato da eliminare è contenuto nel primo nodo
        if (data.equals(head.data)) {
            head = head.next; 	// Sposta la testa al nodo successivo
            if (head == null)   // Se la lista diventa vuota, aggiorna anche tail
                tail = null;

            size--;				// aggiorno il numero di modifiche e la size
            numeroModifiche++;
            return true;		// ritorno true in quanto il dato è stato tovato
        }

        // Scorre la lista per trovare il nodo da rimuovere
        Node current = head;
        while (current.next != null) {
            if (data.equals(current.next.data)) {
                // Rimuove il nodo
                current.next = current.next.next;
                if (current.next == null)	// Se è stato rimosso l'ultimo nodo, aggiorna tail
                    tail = current;
                
                size--;			// aggiorno il numero di modifiche e la size
                numeroModifiche++;
                return true;	// ritorno true in quanto il dato è stato tovato
            }
            current = current.next; // Passa al nodo successivo
        }

        // Se non è stato trovato il nodo, restituisce false
        return false;
    }

    @Override
    public Iterator<T> iterator() {
        return new Itr();
    }

    /**
     * Classe che realizza un iteratore fail-fast per HashLinkedList.
     */
    private class Itr implements Iterator<T> {

    	private Node lastNode;	// Riferimento all'ultimo nodo visitato durante l'iterazione.
    	private final int expectedModifications;  // Numero di modifiche attese per la lista	

        private Itr() {
        	// Salva il numero attuale di modifiche per confrontarlo durante l'iterazione
            this.expectedModifications = numeroModifiche;
            lastNode = null;
        }

        @Override
        public boolean hasNext() {
        	// Se lastNode è null, significa che non si è ancora iniziato con l'iterazione, 
        	// quindi ritorna true se la lista non è vuota, false altrimenti.
        	if(lastNode == null) {
        		return head != null;
        	}
        	// Se lastNode non è null, controlla se c'è un nodo successivo a lastNode 
            return lastNode.next != null;
        }

        @Override
        public T next() {
        	// Controlla se la lista è stata modificata durante l'iterazione
        	if (expectedModifications != numeroModifiche) 
                throw new ConcurrentModificationException("==ERRORE:La lista è stata modificata"
                		+ " mentre era in iterazione==");
        	// Se non ci sono più elementi nella lista, lancia una NoSuchElementException
        	if (!hasNext()) {
                throw new NoSuchElementException("==ERRORE: Non ci sono più elementi nella lista==");
            }
        	// Se lastNode è null, significa che siamo al primo nodo, quindi viene impostiato su head
        	if(lastNode == null) {
        		lastNode = head; 	// Inizializza lastNode al primo nodo della lista
      			return head.data;	// Restituisce il dato del primo nodo
        	}
        	// Altrimenti, si sposta lastNode al nodo successivo nella lista
        	lastNode = lastNode.next;
        	// Restituisce il dato del nodo successivo
       		return lastNode.data;
        }
        
    }

}