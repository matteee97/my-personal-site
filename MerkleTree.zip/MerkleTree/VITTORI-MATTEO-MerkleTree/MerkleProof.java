package it.unicam.cs.asdl2425.mp1;

import java.util.Iterator;

/**
 * Una classe che rappresenta una prova di Merkle per un determinato albero di
 * Merkle ed un suo elemento o branch. Oggetti di questa classe rappresentano un
 * proccesso di verifica auto-contenuto, dato da una sequenza di oggetti
 * MerkleProofHash che rappresentano i passaggi necessari per validare un dato
 * elemento o branch in un albero di Merkle decisi al momento di costruzione
 * della prova.
 * 
 * @author Luca Tesei, Marco Caputo (template), Matteo Vittori matteo01.vittori@studenti.unicam.it (implementazione)
 */
public class MerkleProof {

    /**
     * La prova di Merkle, rappresentata come una lista concatenata di oggetti
     * MerkleProofHash.
     */
    private final HashLinkedList<MerkleProofHash> proof;

    /**
     * L'hash della radice dell'albero di Merkle per il quale la prova è stata
     * costruita.
     */
    private final String rootHash;

    /**
     * Lunghezza massima della prova, dato dal numero di hash che la compongono
     * quando completa. Serve ad evitare che la prova venga modificata una volta
     * che essa sia stata completamente costruita.
     */
    private final int length;

    /**
     * Parametro utilizzato per evitare di dover riscrivere ogni volta il messaggio
     * di errore nel caso di input nullo
     */
    private static final String NULL_INPUT_ERROR = 
    		"==ERRORE: il dato inserito non può essere null==";
    /**
     * Costruisce una nuova prova di Merkle per un dato albero di Merkle,
     * specificando la radice dell'albero e la lunghezza massima della prova. La
     * lunghezza massima della prova è il numero di hash che la compongono
     * quando completa, oltre il quale non è possibile aggiungere altri hash.
     *
     * @param rootHash
     *                     l'hash della radice dell'albero di Merkle.
     * @param length
     *                     la lunghezza massima della prova.
     */
    public MerkleProof(String rootHash, int length) {
        if (rootHash == null)
            throw new IllegalArgumentException("The root hash is null");
        this.proof = new HashLinkedList<>();
        this.rootHash = rootHash;
        this.length = length;
    }

    /**
     * Restituisce la massima lunghezza della prova, dato dal numero di hash che
     * la compongono quando completa.
     *
     * @return la massima lunghezza della prova.
     */
    public int getLength() {
        return length;
    }

    /**
     * Aggiunge un hash alla prova di Merkle, specificando se esso dovrebbe
     * essere concatenato a sinistra o a destra durante la verifica della prova.
     * Se la prova è già completa, ovvero ha già raggiunto il massimo numero di
     * hash deciso alla sua costruzione, l'hash non viene aggiunto e la funzione
     * restituisce false.
     * 
     * @param hash
     *                   l'hash da aggiungere alla prova.
     * @param isLeft
     *                   true se l'hash dovrebbe essere concatenato a sinistra,
     *                   false altrimenti.
     * @return true se l'hash è stato aggiunto con successo, false altrimenti.
     */
    public boolean addHash(String hash, boolean isLeft) {
    	// Controlla se il dato è null e lancia un'eccezione se lo è.
    	if(hash == null) 
    		throw new IllegalArgumentException(NULL_INPUT_ERROR);
    	//	Se la prova è già completa, ovvero ha già raggiunto il massimo numero di
       	//	hash deciso alla sua costruzione, l'hash non viene aggiunto e la funzione
       	//	restituisce false.
    	if(proof.getSize() >= this.getLength()) 
    		return false;
    	//	Aggiunge un hash alla prova di Merkle con param isLeft true o false in base a come specificato
   		proof.addAtTail(new MerkleProofHash(hash, isLeft));
    	
    	return true;
    }

    /**
     * Rappresenta un singolo step di una prova di Merkle per la validazione di
     * un dato elemento.
     */
    public static class MerkleProofHash {
        /**
         * L'hash dell'oggetto.
         */
        private final String hash;

        /**
         * Indica se l'hash dell'oggetto dovrebbe essere concatenato a sinistra
         * durante la verifica della prova.
         */
        private final boolean isLeft;

        public MerkleProofHash(String hash, boolean isLeft) {
            if (hash == null)
                throw new IllegalArgumentException("The hash cannot be null");

            this.hash = hash;
            this.isLeft = isLeft;
        }

        /**
         * Restituisce l'hash dell'oggetto MerkleProofHash.
         *
         * @return l'hash dell'oggetto MerkleProofHash.
         */
        public String getHash() {
            return hash;
        }

        /**
         * Restituisce true se, durante la verifica della prova, l'hash
         * dell'oggetto dovrebbe essere concatenato a sinistra, false
         * altrimenti.
         *
         * @return true se l'hash dell'oggetto dovrebbe essere concatenato a
         *         sinistra, false altrimenti.
         */
        public boolean isLeft() {
            return isLeft;
        }

        @Override
        public boolean equals(Object obj) {
            /*
             * Due MerkleProofHash sono uguali se hanno lo stesso hash e lo
             * stesso flag isLeft
             */
        	
        	// Controlla se i riferimenti sono uguali
        	if (this == obj)
        		return true;
        	// se l'oggetto passato è nullo o non è di tipo MerkleProofHash restituisce false
        	if(obj == null || obj.getClass() != this.getClass())
        		return false;
        	
        	MerkleProofHash that = (MerkleProofHash) obj;
        	// Restituisce true se, hash e flag isLeft sono uguali,
            // false altrimenti.
        	return ((that.isLeft() == this.isLeft) && (that.hash.equals(this.hash)));
        }

        @Override
        public String toString() {
            return hash + (isLeft ? "L" : "R");
        }

        @Override
        public int hashCode() {
            /*
             * Implementare in accordo a equals
             */
        	int result = hash.hashCode();
        	// Combina il risultato con il valore di `isLeft` usando una costante 31.
            // Se `isLeft` è true, aggiunge 31 al risultato, altrimenti aggiunge 0.
            result = 31 * result + (isLeft ? 31 : 0);
            return result;
        }
    }

    /**
     * Valida un dato elemento per questa prova di Merkle. La verifica avviene
     * combinando l'hash del dato con l'hash del primo oggetto MerkleProofHash
     * in un nuovo hash, il risultato con il successivo e così via fino
     * all'ultimo oggetto, e controllando che l'hash finale coincida con quello
     * del nodo radice dell'albero di Merkle orginale.
     *
     * @param data
     *                 l'elemento da validare.
     * @return true se il dato è valido secondo la prova; false altrimenti.
     * @throws IllegalArgumentException
     *                                      se il dato è null.
     */
    public boolean proveValidityOfData(Object data) {
    	// lancia un ecceziione IllegalArgumentException se il dato è null.
    	if(data == null)
    		throw new IllegalArgumentException(NULL_INPUT_ERROR);
    	
    	// ritorna true sse l'hash ottenuto è uguale alla radice data
    	return validateHash(HashUtil.dataToHash(data));
    }

    /**
     * Valida un dato branch per questa prova di Merkle. La verifica avviene
     * combinando l'hash del branch con l'hash del primo oggetto MerkleProofHash
     * in un nuovo hash, il risultato con il successivo e così via fino
     * all'ultimo oggetto, e controllando che l'hash finale coincida con quello
     * del nodo radice dell'albero di Merkle orginale.
     *
     * @param branch
     *                   il branch da validare.
     * @return true se il branch è valido secondo la prova; false altrimenti.
     * @throws IllegalArgumentException
     *                                      se il branch è null.
     */
    public boolean proveValidityOfBranch(MerkleNode branch) {
    	// lancia un ecceziione IllegalArgumentException se il dato è null.
    	if(branch == null)
    		throw new IllegalArgumentException(NULL_INPUT_ERROR);
    	
    	// ritorna true sse l'hash ottenuto è uguale alla radice data
    	return validateHash(branch.getHash());
    }
    
    /**
     * Valida un dato initialHash per questa prova di Merkle. La verifica avviene
     * combinando l'hash dato con l'hash del primo oggetto MerkleProofHash
     * in un nuovo hash, il risultato con il successivo e così via fino
     * all'ultimo oggetto, e controllando che l'hash finale coincida con quello
     * del nodo radice dell'albero di Merkle orginale.
     *
     * @param initialHash
     *                   l'hash da validare.
     * @return true se l'hash è valido secondo la prova; false altrimenti.
     */
    private boolean validateHash(String initialHash) {
    	// salva l'hash dato in finalHash che verrà poi usato per tenere traccia dei risultati intermedi 
    	// fino ad arrivare al risultato finale che verrà usato per controllare se coincide con rootHash
    	String finalHash = initialHash;
    	// iterazione su tutti gli elementi della lista
    	for(MerkleProofHash current : proof) {
    		// Calcola l'hash MD5 del risultato concatenato
    		finalHash = HashUtil.computeMD5(
    				concatenate(current.hash , finalHash , current.isLeft).getBytes());
    	}
    	// ritorna true sse l'hash ottenuto è uguale alla radice data  	
    	return finalHash.equals(rootHash);
    }
    
    /**
     * Metodo di supporto per concatenare due hash.
     * La concatenazione dipende dal valore del flag `isLeft`:
     * - Se `isLeft` è `true`, l'hash `hash1` viene concatenato a sinistra di `hash2`.
     * - Se `isLeft` è `false`, l'hash `hash1` viene concatenato a destra di `hash2`.
     *
     * @param hash1   L'hash del nodo corrente della prova (nodo fratello).
     * @param hash2   L'hash accumulato fino al passo corrente.
     * @param isLeft  Flag che indica l'ordine di concatenazione:
     *                - `true` per concatenare `hash1` a sinistra.
     *                - `false` per concatenare `hash1` a destra.
     * @return        Restituisce la stringa risultante dalla concatenazione ordinata degli hash.
     */
    private String concatenate(String hash1, String hash2, boolean isLeft) {
		return isLeft ? hash1 + hash2 : hash2 + hash1;
    }

}
